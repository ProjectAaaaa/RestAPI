package com.apidemo.APIDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
